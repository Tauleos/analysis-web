self.__precacheManifest = [
  {
    "revision": "5d5d9eefa31e5e13a6610d9fa7a283bb",
    "url": "/static/media/logo.5d5d9eef.svg"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "26a942c46ee8b7b8cd45",
    "url": "/static/js/main.07aebce8.chunk.js"
  },
  {
    "revision": "c2fe51fb2c5266bfb6e9",
    "url": "/static/js/2.0ca42e0f.chunk.js"
  },
  {
    "revision": "26a942c46ee8b7b8cd45",
    "url": "/static/css/main.4e9eb645.chunk.css"
  },
  {
    "revision": "c2fe51fb2c5266bfb6e9",
    "url": "/static/css/2.0bfeb878.chunk.css"
  },
  {
    "revision": "c5cddd2206f84a287f2d0b6091b2f82c",
    "url": "/index.html"
  }
];